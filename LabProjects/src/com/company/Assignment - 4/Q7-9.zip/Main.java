package com.company;
//MIHIR SAINI 9920102054 E2
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Employee employee=new Employee("Mihir Saini", "224-Z", "25/12/02");
        ProductionWorker productionWorker=new ProductionWorker("Mihir Saini", "224-Z", "25/12/02", 1, 22334.5);
        productionWorker.printDetails();
        productionWorker.setEmpNo("8823- vv");
        ShiftSupervisor shiftSupervisor=new ShiftSupervisor("Mihir Saini", "224-Z", "25/12/02", 774829.239, 7500);
        shiftSupervisor.printDetails();
        TeamLeader teamLeader=new TeamLeader("Mihir Saini", "224-Z", "25/12/02", 1,22553.2,7400, 55,45);
        teamLeader.printEligibility();
    }
}
