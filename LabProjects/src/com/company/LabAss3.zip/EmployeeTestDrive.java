package com.company;
//MIHIR SAINI 9920102054 E2
public class EmployeeTestDrive {
    public static void main(String[] args) {
        Employee emp=new Employee();
        emp.getData("MIHIR SAINI", 2054, 205040, "SOFTWARE DEVELOPER", 5);
        emp.dispData();
        emp.calcBonusSalary();
    }
}
