package com.company;
//MIHIR SAINI 9920102054 E2
public class Employee {
    String name;
    int id;
    double salary;
    String designation;
    int yearsOfExp;
    public void getData(String name, int id, double salary, String designation, int yearsOfExp) {
        this.name = name;
        this.id = id;
        this.salary = salary;
        this.designation = designation;
        this.yearsOfExp = yearsOfExp;
    }
    public void dispData(){
        System.out.println("Employee Name: " + name);
        System.out.println("Employee ID: " + id);
        System.out.println("Employee Salary: " + salary );
        System.out.println("Employee Designation: " + designation );
        System.out.println("Years of experience: " + yearsOfExp);
    }
    public void calcBonusSalary(){
        if(yearsOfExp>=2){
            salary+=2000;
            System.out.println("Updated data: ");
            dispData();
        }
        else if(yearsOfExp>=5){
            salary+=5000;
            System.out.println("Updated data: ");
            dispData();
        }
        else System.out.println("Not enough experience");
    }
}

