public class RandomWord {
    public static void main(String[] args) {
        System.out.println("Random Word");
    }
}
