public class HelloGoodbye {
    public static void main(String[] args) {
        System.out.println("Goodbye");
    }
}
