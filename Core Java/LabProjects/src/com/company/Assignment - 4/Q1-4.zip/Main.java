package com.company;
//MIHIR SAINI 9920102054 E2
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Student student1=new Student("MIHIR SAINI", 992054, 9927099,"Veer Shivaji", "Noida", "Haridwar", "ms224@gmail.com");
        student1.printDetails(992054);
        Student student2=new Student("AJITESH MISHRA", 992033, 9927091,"abc", "Noida", "Kanpur", "ms225@gmail.com");
        Student student3=new Student("ADEEB MOHSIN", 992050, 9927092,"def", "Noida", "Bareilly", "ms226@gmail.com");
        Student student4=new Student("YASH GUPTA", 992044, 9927093,"hij", "Noida", "Noida", "ms227@gmail.com");
        Student student5=new Student("ISHAAN SARASWAT", 992040, 9927094,"klm", "Noida", "Moradabad", "ms228@gmail.com");
        Student student6=new Student("VAISHNAVI DUBEY", 992052, 9927095,"nop", "Noida", "Bhopal", "ms229@gmail.com");
        Student student7=new Student("KUNWAR ADITYA", 992012, 9927096,"qrs", "Noida", "Lucknow", "ms220@gmail.com");
        Student student8=new Student("SHRIJIT SRIVASTAV", 992061, 9927097,"tuv", "Noida", "Lucknow", "ms221@gmail.com");
        Student student9=new Student("SURYANSH GUPTA", 9920105, 9927098,"wxy", "Noida", "Goa", "ms222@gmail.com");
        Student student10=new Student("SANSKAR DUBEY", 992072, 9927090,"z", "Noida", "Kerala", "ms223@gmail.com");
        student4.printDetails(992044);


    }
}
