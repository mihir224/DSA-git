package com.company;
//MIHIR SAINI 9920102054 E2
public class UGCourse extends Course {
    public UGCourse(String code, String name, double credit) {
        super(code, name, credit);
    }
}
