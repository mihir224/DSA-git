package com.company;
//MIHIR SAINI 9920102054 E2
public class PGCourse extends Course {
        public PGCourse(String code, String name, double credit){
            super(code, name, credit);
        }
}
