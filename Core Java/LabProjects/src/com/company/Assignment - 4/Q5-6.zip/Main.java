package com.company;
//MIHIR SAINI 9920102054 E2
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
     Employee employee1=new Employee("2194Z", "MIHIR SAINI", "CSE","25/12/2002","Software Engineer", 1997, 99271004);
     employee1.printDetails();
     Employee employee2=new Employee("2194A", "AJITESH MISHRA", "CSE","25/12/2001","Software Engineer", 1996, 99271003);
     Employee employee3=new Employee("2194V", "ADEEB MOHSIN", "CSE","25/12/2000","Software Engineer", 1995, 99271002);
     Employee employee4=new Employee("2194B", "ISHAAN SARASWAT", "CSE","25/12/1999","Software Engineer", 1994, 99271001);
     Employee employee5=new Employee("2194N", "YASH GUPTA", "CSE","25/12/1998","Software Engineer", 1993, 99271000);
     Faculty faculty=new Faculty("2194Z", "MIHIR SAINI", "CSE","25/12/2002","Software Engineer", 1997, 99271004);
     faculty.addSubject("MATHEMATICS");
        faculty.addSubject("CHEMISTRY");
        faculty.addSubject("PHYSICS");
        faculty.printSubjects(faculty.getSubject());
        DUGC dugc=new DUGC("2194Z", "MIHIR SAINI", "CSE","25/12/2002","Software Engineer", 1997, 99271004);
        System.out.println(dugc.toString());


    }
}
