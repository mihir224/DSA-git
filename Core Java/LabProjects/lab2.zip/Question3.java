package com.company;
//MIHIR SAINI 9920102054 E2
public class Question3 {
   public int sumAvgRunningInt(int lowerBound,int upperBound){
       int sum=0;
       for(int i=lowerBound;i<=upperBound;i++){
           sum=sum+i;
       }
       return sum;
   }
}
