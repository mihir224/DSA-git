package com.company;
//MIHIR SAINI 9920102054 E2
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //code for ques1
//        Question1 q1=new Question1();
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Enter any number: ");
//        int n=scanner.nextInt();
//        if(q1.checkOddEven(n)){
//            System.out.println(+ n + " is even");
//        }
//        else System.out.println( + n + " is odd");
        //code for ques2
//        Question2 q2=new Question2();
//         Scanner scanner=new Scanner(System.in);
//        System.out.println("Enter any number: ");
//        int n=scanner.nextInt();
//        q2.printDayInWord(n);
        //code for q3
//        Question3 q3=new Question3();
//        System.out.println(q3.sumAvgRunningInt(3, 5));
        //code for q4
//        Question4 q4=new Question4();
//        int b=q4.product1toN(5);
//        System.out.println(b);
        //code for q5
//        Question5 question5=new Question5();
//        question5.CozaLozaWoza(110);
//        Question6 question6=new Question6();
//        question6.ExtractDigits(1358);
    }
}
