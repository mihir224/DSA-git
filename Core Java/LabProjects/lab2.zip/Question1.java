package com.company;
//MIHIR SAINI 9920102054 E2
public class Question1 {
  public boolean checkOddEven(int n){
      if(n%2==0){
          return true;
      }
      else return false;
    }
}
