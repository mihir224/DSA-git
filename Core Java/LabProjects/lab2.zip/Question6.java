package com.company;

public class Question6 {
    public void ExtractDigits(int n){
        String s=Integer.toString(n);
        for(int i=0;i<s.length();i++){
            System.out.println(s.charAt(i));
        }
    }
}
