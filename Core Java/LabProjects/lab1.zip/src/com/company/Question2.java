package com.company;
//MIHIR SAINI 9920102054 E2
public class Question2 {
    public void factors(int n){
        for(int i=1;i<=n;i++)
        {
            if(n%i==0){
                System.out.println(i);
            }
        }
    }
}
