package com.company;
//MIHIR SAINI 9920102054 E2
public class Question1 {
    public double fahrenToCel(double f){
        double c=(f-32.0)*(5.0/9.0);
        return c;
    }
}
