package com.company;
//MIHIR SAINI 9920102054 E2
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
   public static void main(String[] args) {
      ArrayList<Student> student=new ArrayList<>();
      student.add(new Student("Mihir Saini", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Parth Dubey", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Ajitesh Mishra", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Adeeb Mohsin", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Yash Gupta", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Ishaan Saraswat", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Kartik Sharma", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Vaishnavi Dubey", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Shrijit Srivastav", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      student.add(new Student("Jai Arora", 99293, 92399393, "Veer", "Noida", "Haridwar","ms224@gmail.com"));
      Iterator iterator=student.iterator();
      while(iterator.hasNext()){
         System.out.println(iterator.next());
      }
   }
}
